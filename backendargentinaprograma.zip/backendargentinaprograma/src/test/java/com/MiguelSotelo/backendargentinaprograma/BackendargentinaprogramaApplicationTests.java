package com.MiguelSotelo.backendargentinaprograma;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendargentinaprogramaApplicationTests {

	@Test
	void contextLoads() {
	}

}
