package com.MiguelSotelo.backendargentinaprograma;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendargentinaprogramaApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackendargentinaprogramaApplication.class, args);
	}

}
